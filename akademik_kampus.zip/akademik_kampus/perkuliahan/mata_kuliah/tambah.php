<?php
session_start();

require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../../auth/login.php");
    exit;
}

$error = '';

if (isset($_POST['simpan'])) {
    $kode_mk = trim($_POST['kode_mk'] ?? '');
    $nama_mk = trim($_POST['nama_mk'] ?? '');
    $sks = (int) ($_POST['sks'] ?? 0);
    $semester = (int) ($_POST['semester'] ?? 0);
    $id_prodi = (int) ($_POST['id_prodi'] ?? 0);

    if (
        $kode_mk === '' ||
        $nama_mk === '' ||
        $sks < 1 ||
        $semester < 1 ||
        $semester > 8 ||
        $id_prodi < 1
    ) {
        $error = "Data yang dimasukkan belum valid. Periksa kembali formulir.";
    } else {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO mata_kuliah
            (kode_mk, nama_mk, sks, semester, id_prodi)
            VALUES (?, ?, ?, ?, ?)
        ");

        if ($stmt) {
            mysqli_stmt_bind_param(
                $stmt,
                "ssiii",
                $kode_mk,
                $nama_mk,
                $sks,
                $semester,
                $id_prodi
            );

            if (mysqli_stmt_execute($stmt)) {
                $id_baru = mysqli_insert_id($conn);

                catatAktivitas(
                    $conn,
                    'Tambah',
                    'mata_kuliah',
                    $id_baru,
                    "Menambahkan mata kuliah: " . $nama_mk
                );

                mysqli_stmt_close($stmt);

                header("Location: index.php");
                exit;
            } else {
                $error = "Gagal menyimpan data. Periksa kembali data yang dimasukkan.";
            }

            mysqli_stmt_close($stmt);
        } else {
            $error = "Gagal menyiapkan penyimpanan data.";
        }
    }
}

$prodi = mysqli_query(
    $conn,
    "SELECT * FROM prodi ORDER BY nama_prodi ASC"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Mata Kuliah</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assets/css/tambah.css">
</head>
<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="sidebar-header">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <nav class="sidebar-menu">

        <a href="../../../dashboard/index.php">Dashboard</a>
        <a href="../../../akun/index.php">Data Akun</a>
        <a href="../../fakultas/index.php">Fakultas</a>
        <a href="../../prodi/index.php">Program Studi</a>

        <a href="../../mahasiswa/index.php">Mahasiswa</a>
        <a href="../../dosen/index.php">Dosen</a>
        <a href="../../kelas/index.php">Kelas</a>
        <a href="index.php" class="active">Mata Kuliah</a>
        <a href="../krs/index.php">KRS</a>

    </nav>

    <div class="sidebar-footer">
        <a href="../../../auth/logout.php">Logout</a>
    </div>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Tambah Mata Kuliah</h2>
            <p>Silakan isi informasi mata kuliah yang akan ditambahkan.</p>
        </div>

        <?php if ($error !== '') : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Kode Mata Kuliah</label>
                <input
                    type="text"
                    name="kode_mk"
                    value="<?php echo htmlspecialchars($_POST['kode_mk'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Nama Mata Kuliah</label>
                <input
                    type="text"
                    name="nama_mk"
                    value="<?php echo htmlspecialchars($_POST['nama_mk'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>SKS</label>
                <input
                    type="number"
                    name="sks"
                    min="1"
                    value="<?php echo htmlspecialchars($_POST['sks'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Semester</label>
                <input
                    type="number"
                    name="semester"
                    min="1"
                    max="8"
                    value="<?php echo htmlspecialchars($_POST['semester'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Program Studi</label>
                <select name="id_prodi" required>
                    <option value="">Pilih Program Studi</option>

                    <?php if ($prodi) : ?>
                        <?php while ($p = mysqli_fetch_assoc($prodi)) : ?>
                            <option
                                value="<?php echo $p['id_prodi']; ?>"
                                <?php
                                if (
                                    isset($_POST['id_prodi']) &&
                                    $_POST['id_prodi'] == $p['id_prodi']
                                ) {
                                    echo 'selected';
                                }
                                ?>
                            >
                                <?php echo htmlspecialchars($p['nama_prodi']); ?>
                            </option>
                        <?php endwhile; ?>
                    <?php endif; ?>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="simpan">Simpan</button>
                <a href="index.php">Batal</a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>