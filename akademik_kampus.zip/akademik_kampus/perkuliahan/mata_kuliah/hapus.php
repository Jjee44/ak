<?php
session_start();

require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id < 1) {
    echo "<script>
        alert('ID data tidak valid.');
        window.location='index.php';
    </script>";
    exit;
}

$id = (int) $id;

// Ambil nama mata kuliah sebelum data dihapus.
$stmt = mysqli_prepare(
    $conn,
    "SELECT nama_mk FROM mata_kuliah WHERE id_mk = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$data) {
    echo "<script>
        alert('Data mata kuliah tidak ditemukan.');
        window.location='index.php';
    </script>";
    exit;
}

$nama_mk = $data['nama_mk'];

// Hapus data mata kuliah.
$stmt = mysqli_prepare(
    $conn,
    "DELETE FROM mata_kuliah WHERE id_mk = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    // Catat aktivitas hanya jika penghapusan berhasil.
    catatAktivitas(
        $conn,
        'Hapus',
        'mata_kuliah',
        $id,
        "Menghapus mata kuliah: " . $nama_mk
    );

    mysqli_stmt_close($stmt);

    header("Location: index.php");
    exit;
}

mysqli_stmt_close($stmt);

echo "<script>
    alert('Data tidak dapat dihapus karena masih digunakan oleh data lain.');
    window.location='index.php';
</script>";
exit;
?>