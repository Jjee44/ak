<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    echo "<script>
        alert('ID KRS tidak valid.');
        window.location='index.php';
    </script>";
    exit;
}

$id = (int) $id;

// Ambil informasi KRS sebelum data dihapus.
$stmt = mysqli_prepare($conn, "
    SELECT
        krs.id_krs,
        krs.id_mahasiswa,
        krs.id_kelas,
        mahasiswa.nama_mahasiswa
    FROM krs
    JOIN mahasiswa ON krs.id_mahasiswa = mahasiswa.id_mahasiswa
    WHERE krs.id_krs = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$data) {
    echo "<script>
        alert('Data KRS tidak ditemukan.');
        window.location='index.php';
    </script>";
    exit;
}

$nama_mahasiswa = $data['nama_mahasiswa'];
$id_kelas = $data['id_kelas'];

// Hapus data KRS.
$stmt = mysqli_prepare($conn, "
    DELETE FROM krs
    WHERE id_krs = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {

    // Catat aktivitas hanya jika penghapusan berhasil.
    catatAktivitas(
        $conn,
        'Hapus',
        'krs',
        $id,
        'Menghapus data KRS mahasiswa: ' . $nama_mahasiswa .
        ', kelas ID: ' . $id_kelas
    );

    mysqli_stmt_close($stmt);

    header("Location: index.php");
    exit;
}

mysqli_stmt_close($stmt);

echo "<script>
    alert('Data KRS gagal dihapus.');
    window.location='index.php';
</script>";
exit;
?>