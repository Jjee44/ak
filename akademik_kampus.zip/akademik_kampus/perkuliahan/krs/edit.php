<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    die("ID KRS tidak valid.");
}

$id = (int) $id;

$stmt = mysqli_prepare($conn, "
    SELECT * FROM krs
    WHERE id_krs = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$data) {
    die("Data KRS tidak ditemukan.");
}

if (isset($_POST['update'])) {
    $id_mahasiswa = (int) ($_POST['id_mahasiswa'] ?? 0);
    $id_kelas = (int) ($_POST['id_kelas'] ?? 0);
    $tanggal = $_POST['tanggal_pengisian'] ?? '';
    $status = $_POST['status'] ?? '';

    $status_valid = ['Menunggu', 'Disetujui', 'Ditolak'];

    if ($id_mahasiswa <= 0 || $id_kelas <= 0 || $tanggal === '' || !in_array($status, $status_valid, true)) {
        $error = "Semua data wajib diisi dengan benar.";
    } else {
        $stmt = mysqli_prepare($conn, "
            UPDATE krs SET
                id_mahasiswa = ?,
                id_kelas = ?,
                tanggal_pengisian = ?,
                status = ?
            WHERE id_krs = ?
        ");

        if ($stmt) {
            mysqli_stmt_bind_param(
                $stmt,
                "iissi",
                $id_mahasiswa,
                $id_kelas,
                $tanggal,
                $status,
                $id
            );

            if (mysqli_stmt_execute($stmt)) {
                catatAktivitas(
                    $conn,
                    'Edit',
                    'krs',
                    $id,
                    'Mengubah data KRS ID: ' . $id .
                    ', mahasiswa ID: ' . $id_mahasiswa .
                    ', kelas ID: ' . $id_kelas
                );

                mysqli_stmt_close($stmt);

                header("Location: index.php");
                exit;
            } else {
                $error = "Gagal menyimpan data. Pastikan mahasiswa belum mengambil kelas yang sama dan seluruh data sudah benar.";
            }

            mysqli_stmt_close($stmt);
        } else {
            $error = "Gagal menyiapkan perintah perubahan data.";
        }
    }

    // Pertahankan isian pengguna jika proses update gagal.
    $data['id_mahasiswa'] = $id_mahasiswa;
    $data['id_kelas'] = $id_kelas;
    $data['tanggal_pengisian'] = $tanggal;
    $data['status'] = $status;
}

$mahasiswa = mysqli_query($conn, "
    SELECT * FROM mahasiswa
    ORDER BY nama_mahasiswa ASC
");

$kelas = mysqli_query($conn, "
    SELECT
        kelas.id_kelas,
        kelas.nama_kelas,
        mata_kuliah.nama_mk
    FROM kelas
    JOIN mata_kuliah ON kelas.id_mk = mata_kuliah.id_mk
    ORDER BY kelas.nama_kelas ASC
");

if (!$mahasiswa || !$kelas) {
    die("Gagal mengambil data mahasiswa atau kelas.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit KRS</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assets/css/edit.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK KAMPUS</h2>
        <p>INFORMATION SYSTEM</p>
    </div>

    <div class="menu-title">MENU UTAMA</div>
    <a href="../../../dashboard/index.php"><span>▦</span> Dashboard</a>
    <a href="../../../akun/index.php"><span>♙</span> Data Akun</a>

    <div class="menu-title">DATA AKADEMIK</div>
    <a href="../../fakultas/index.php"><span>▤</span> Fakultas</a>
    <a href="../../prodi/index.php"><span>▤</span> Program Studi</a>
    <a href="../../mahasiswa/index.php"><span>♙</span> Mahasiswa</a>
    <a href="../../dosen/index.php"><span>♧</span> Dosen</a>
    <a href="../../kelas/index.php"><span>▣</span> Kelas</a>

    <div class="menu-title">PERKULIAHAN</div>
    <a href="../mata_kuliah/index.php"><span>▤</span> Mata Kuliah</a>
    <a href="index.php" class="active"><span>▣</span> KRS</a>

    <div class="menu-title">LAINNYA</div>
    <a href="../../../auth/logout.php" class="logout"><span>↪</span> Logout</a>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Edit KRS</h2>
            <p>Silakan ubah informasi KRS yang ingin diperbarui.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Mahasiswa</label>
                <select name="id_mahasiswa" required>

                    <?php while ($m = mysqli_fetch_assoc($mahasiswa)) : ?>
                        <option
                            value="<?php echo $m['id_mahasiswa']; ?>"
                            <?php echo ($data['id_mahasiswa'] == $m['id_mahasiswa']) ? 'selected' : ''; ?>
                        >
                            <?php echo htmlspecialchars($m['nim'] . ' - ' . $m['nama_mahasiswa']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-group">
                <label>Kelas / Mata Kuliah</label>
                <select name="id_kelas" required>

                    <?php while ($k = mysqli_fetch_assoc($kelas)) : ?>
                        <option
                            value="<?php echo $k['id_kelas']; ?>"
                            <?php echo ($data['id_kelas'] == $k['id_kelas']) ? 'selected' : ''; ?>
                        >
                            <?php echo htmlspecialchars($k['nama_kelas'] . ' - ' . $k['nama_mk']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-group">
                <label>Tanggal Pengisian</label>
                <input
                    type="date"
                    name="tanggal_pengisian"
                    value="<?php echo htmlspecialchars($data['tanggal_pengisian']); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status" required>

                    <option value="Menunggu"
                        <?php echo ($data['status'] == 'Menunggu') ? 'selected' : ''; ?>>
                        Menunggu
                    </option>

                    <option value="Disetujui"
                        <?php echo ($data['status'] == 'Disetujui') ? 'selected' : ''; ?>>
                        Disetujui
                    </option>

                    <option value="Ditolak"
                        <?php echo ($data['status'] == 'Ditolak') ? 'selected' : ''; ?>>
                        Ditolak
                    </option>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="update" class="btn btn-save">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>