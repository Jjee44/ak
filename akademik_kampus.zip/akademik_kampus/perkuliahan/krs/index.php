<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../../auth/login.php");
    exit;
}

$query = mysqli_query($conn, "
    SELECT
        krs.*,
        mahasiswa.nim,
        mahasiswa.nama_mahasiswa,
        kelas.nama_kelas,
        mata_kuliah.nama_mk,
        dosen.nama_dosen
    FROM krs
    JOIN mahasiswa ON krs.id_mahasiswa = mahasiswa.id_mahasiswa
    JOIN kelas ON krs.id_kelas = kelas.id_kelas
    JOIN mata_kuliah ON kelas.id_mk = mata_kuliah.id_mk
    JOIN dosen ON kelas.id_dosen = dosen.id_dosen
    ORDER BY krs.id_krs ASC
");

if (!$query) {
    die("Gagal mengambil data KRS: " . mysqli_error($conn));
}

$total = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data KRS - Akademik Kampus</title>
    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK KAMPUS</h2>
        <p>INFORMATION SYSTEM</p>
    </div>

    <div class="menu-title">MENU UTAMA</div>
    <a href="../../../dashboard/index.php"><span>▦</span> Dashboard</a>
    <a href="../../../akun/index.php"><span>♙</span> Data Akun</a>

    <div class="menu-title">DATA AKADEMIK</div>
    <a href="../../fakultas/index.php"><span>▤</span> Fakultas</a>
    <a href="../../prodi/index.php"><span>▤</span> Program Studi</a>
    <a href="../../mahasiswa/index.php"><span>♙</span> Mahasiswa</a>
    <a href="../../dosen/index.php"><span>♧</span> Dosen</a>
    <a href="../../kelas/index.php"><span>▣</span> Kelas</a>

    <div class="menu-title">PERKULIAHAN</div>
    <a href="../mata_kuliah/index.php"><span>▤</span> Mata Kuliah</a>
    <a href="index.php" class="active"><span>▣</span> KRS</a>

    <div class="menu-title">LAINNYA</div>
    <a href="../../../auth/logout.php" class="logout"><span>↪</span> Logout</a>

</aside>

<main class="main">

    <header class="topbar">
        <h3>Data KRS</h3>
        <div class="akun-info">
            Akun: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></strong>
        </div>
    </header>

    <section class="content">

        <div class="page-heading">
            <div>
                <h1>Data Kartu Rencana Studi</h1>
                <p>Daftar pengisian KRS mahasiswa.</p>
            </div>

            <a href="tambah.php" class="btn-add">+ Tambah KRS</a>
        </div>

        <div class="data-card">

            <div class="card-header">
                <h3>Daftar KRS Mahasiswa</h3>
                <span class="total-data">
                    Total Data: <?php echo $total; ?>
                </span>
            </div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID KRS</th>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>Kelas</th>
                            <th>Mata Kuliah</th>
                            <th>Dosen</th>
                            <th>Tanggal Pengisian</th>
                            <th>Status</th>
                            <th>Perubahan</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if ($total > 0) : ?>
                            <?php while ($data = mysqli_fetch_assoc($query)) : ?>
                                <tr>
                                    <td>
                                        <span class="id-badge">
                                            <?php echo $data['id_krs']; ?>
                                        </span>
                                    </td>

                                    <td><?php echo htmlspecialchars($data['nim']); ?></td>

                                    <td>
                                        <strong>
                                            <?php echo htmlspecialchars($data['nama_mahasiswa']); ?>
                                        </strong>
                                    </td>

                                    <td><?php echo htmlspecialchars($data['nama_kelas']); ?></td>
                                    <td><?php echo htmlspecialchars($data['nama_mk']); ?></td>
                                    <td><?php echo htmlspecialchars($data['nama_dosen']); ?></td>
                                    <td><?php echo htmlspecialchars($data['tanggal_pengisian']); ?></td>
                                    <td><?php echo htmlspecialchars($data['status']); ?></td>

                                    <td>
                                        <div class="action">
                                            <a href="edit.php?id=<?php echo $data['id_krs']; ?>"
                                               class="btn-edit">
                                                Edit
                                            </a>

                                            <a href="hapus.php?id=<?php echo $data['id_krs']; ?>"
                                               class="btn-delete"
                                               onclick="return confirm('Yakin ingin menghapus KRS ini?')">
                                                Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="9" class="empty">
                                    Belum ada data KRS.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>