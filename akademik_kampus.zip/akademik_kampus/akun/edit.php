<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

$stmt = mysqli_prepare($conn, "SELECT * FROM akun WHERE id_akun = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Data akun tidak ditemukan.");
}

if (isset($_POST['update'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($password != '') {
        $stmt = mysqli_prepare($conn, "
            UPDATE akun
            SET username = ?, password = ?
            WHERE id_akun = ?
        ");

        mysqli_stmt_bind_param($stmt, "ssi", $username, $password, $id);
    } else {
        $stmt = mysqli_prepare($conn, "
            UPDATE akun
            SET username = ?
            WHERE id_akun = ?
        ");

        mysqli_stmt_bind_param($stmt, "si", $username, $id);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Gagal mengubah akun. Username mungkin sudah digunakan.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Akun</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/edit.css">
</head>
<body>

<h1>Edit Akun</h1>

<?php if (isset($error)) : ?>
<p style="color:red;"><?php echo $error; ?></p>
<?php endif; ?>

<form method="POST">
    <label>Username</label><br>
    <input type="text" name="username"
           value="<?php echo htmlspecialchars($data['username']); ?>" required><br><br>

    <label>Password Baru</label><br>
    <input type="password" name="password">
    <small>Kosongkan jika tidak ingin mengganti password.</small><br><br>

    <button type="submit" name="update">Simpan Perubahan</button>
    <a href="index.php">Batal</a>
</form>

</body>
</html>