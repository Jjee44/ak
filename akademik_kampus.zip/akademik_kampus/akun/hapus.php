<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if ($id == $_SESSION['id_akun']) {
    echo "<script>
        alert('Akun yang sedang login tidak dapat menghapus akunnya sendiri!');
        window.location='index.php';
    </script>";
    exit;
}

$stmt = mysqli_prepare($conn, "
    DELETE FROM akun WHERE id_akun = ?
");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    header("Location: index.php");
    exit;
} else {
    echo "<script>
        alert('Gagal menghapus akun.');
        window.location='index.php';
    </script>";
    exit;
}
?>