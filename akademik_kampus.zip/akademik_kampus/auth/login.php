<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

if (isset($_SESSION['id_akun'])) {
    header("Location: ../dashboard/index.php");
    exit;
}

$error = '';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = mysqli_prepare($conn, "
        SELECT id_akun, username, password
        FROM akun
        WHERE username = ?
    ");

    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);

    if ($data && $password === $data['password']) {
        $_SESSION['id_akun'] = $data['id_akun'];
        $_SESSION['username'] = $data['username'];

        header("Location: ../dashboard/index.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Akun</title>
    <link rel="stylesheet" href="../assets/css/login.css?v=2">
</head>
<body>

<div class="login-container">
    <h2>Login Akun</h2>
    <p>Silakan masuk ke Sistem Informasi Akademik Kampus</p>

    <?php if ($error != '') : ?>
        <div class="error">
            <?= htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>

        <button type="submit" name="login">Login</button>
    </form>
</div>

</body>
</html>