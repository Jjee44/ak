
<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

// ========================================
// CEK LOGIN
// ========================================

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../auth/login.php");
    exit;
}

// ========================================
// MENGHITUNG JUMLAH DATA AKADEMIK
// ========================================

function hitungData($conn, $tabel)
{
    $query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM `$tabel`");

    if (!$query) {
        die("Gagal menghitung data $tabel: " . mysqli_error($conn));
    }

    return (int) mysqli_fetch_assoc($query)['total'];
}

$prodi = hitungData($conn, 'prodi');
$mahasiswa = hitungData($conn, 'mahasiswa');
$dosen = hitungData($conn, 'dosen');
$mk = hitungData($conn, 'mata_kuliah');
$kelas = hitungData($conn, 'kelas');
$krs = hitungData($conn, 'krs');

// ========================================
// PAGINATION DATA AKTIVITAS
// ========================================

$batas_aktivitas = 10;

$halaman_aktivitas = isset($_GET['aktivitas_page'])
    ? max(1, (int) $_GET['aktivitas_page'])
    : 1;

$query_total_aktivitas = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM aktivitas"
);

if (!$query_total_aktivitas) {
    die("Gagal menghitung aktivitas: " . mysqli_error($conn));
}

$total_aktivitas = (int) mysqli_fetch_assoc($query_total_aktivitas)['total'];

$total_halaman_aktivitas = max(
    1,
    (int) ceil($total_aktivitas / $batas_aktivitas)
);

$halaman_aktivitas = min(
    $halaman_aktivitas,
    $total_halaman_aktivitas
);

$offset_aktivitas = ($halaman_aktivitas - 1) * $batas_aktivitas;

// Mengambil aktivitas dari paling lama ke paling baru

$query_aktivitas = mysqli_query($conn, "
    SELECT
        aktivitas.id_aktivitas,
        aktivitas.id_akun,
        aktivitas.jenis_aktivitas,
        aktivitas.nama_tabel,
        aktivitas.id_data,
        aktivitas.keterangan,
        aktivitas.tanggal,
        akun.username
    FROM aktivitas
    LEFT JOIN akun
        ON aktivitas.id_akun = akun.id_akun
    ORDER BY aktivitas.id_aktivitas ASC
    LIMIT $batas_aktivitas OFFSET $offset_aktivitas
");

if (!$query_aktivitas) {
    die("Gagal mengambil data aktivitas: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard - Akademik Kampus</title>

    <link rel="stylesheet" href="/akademik_kampus/assests/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assests/css/dashboard.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK KAMPUS</h2>
        <p>INFORMATION SYSTEM</p>
    </div>

    <!-- MENU UTAMA -->

    <div class="menu-title">MENU UTAMA</div>

    <a href="/akademik_kampus/dashboard/index.php" class="active">
        <span>▦</span> Dashboard
    </a>

    <a href="/akademik_kampus/akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="/akademik_kampus/data_akademik/fakultas/index.php">
        <span>▤</span> Fakultas
    </a>

    <a href="/akademik_kampus/data_akademik/prodi/index.php">
        <span>▤</span> Program Studi
    </a>

    <!-- DATA AKADEMIK -->

    <div class="menu-title">DATA AKADEMIK</div>

    <a href="/akademik_kampus/data_akademik/mahasiswa/index.php">
        <span>♙</span> Mahasiswa
    </a>

    <a href="/akademik_kampus/data_akademik/dosen/index.php">
        <span>♧</span> Dosen
    </a>

    <a href="/akademik_kampus/data_akademik/kelas/index.php">
        <span>▣</span> Kelas
    </a>

    <!-- PERKULIAHAN -->

    <div class="menu-title">PERKULIAHAN</div>

    <a href="/akademik_kampus/data_akademik/perkuliahan/mata_kuliah/index.php">
        <span>▤</span> Mata Kuliah
    </a>

    <a href="/akademik_kampus/data_akademik/perkuliahan/krs/index.php">
        <span>▣</span> KRS
    </a>

    <!-- LAINNYA -->

    <div class="menu-title">LAINNYA</div>

    <a href="/akademik_kampus/auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <header class="topbar">

        <h3>Dashboard</h3>

        <div class="akun-info">
            Akun:
            <strong>
                <?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>
            </strong>
        </div>

    </header>

    <section class="content">

        <!-- RINGKASAN DATA AKADEMIK -->

        <div class="section-heading">
            <h2>Ringkasan Data Akademik</h2>
        </div>

        <div class="stats">

            <div class="stat-card">
                <div class="stat-icon">PROGRAM STUDI</div>
                <h2><?php echo $prodi; ?></h2>
            </div>

            <div class="stat-card">
                <div class="stat-icon">MAHASISWA</div>
                <h2><?php echo $mahasiswa; ?></h2>
            </div>

            <div class="stat-card">
                <div class="stat-icon">DOSEN</div>
                <h2><?php echo $dosen; ?></h2>
            </div>

            <div class="stat-card">
                <div class="stat-icon">MATA KULIAH</div>
                <h2><?php echo $mk; ?></h2>
            </div>

            <div class="stat-card">
                <div class="stat-icon">KELAS</div>
                <h2><?php echo $kelas; ?></h2>
            </div>

            <div class="stat-card">
                <div class="stat-icon">KRS</div>
                <h2><?php echo $krs; ?></h2>
            </div>

        </div>

        <!-- DATA AKTIVITAS -->

        <div class="section-heading">
            <h2>Data Aktivitas Terbaru</h2>
        </div>

        <div class="activity-table">

            <table>

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Jenis Aktivitas</th>
                        <th>Nama Tabel</th>
                        <th>ID Data</th>
                        <th>Keterangan</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (mysqli_num_rows($query_aktivitas) > 0) : ?>

                        <?php $no = $offset_aktivitas + 1; ?>

                        <?php while ($aktivitas = mysqli_fetch_assoc($query_aktivitas)) : ?>

                            <tr>
                                <td><?php echo $no++; ?></td>

                                <td>
                                    <?php echo htmlspecialchars($aktivitas['username'] ?? 'Tidak diketahui'); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($aktivitas['jenis_aktivitas']); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($aktivitas['nama_tabel']); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($aktivitas['id_data']); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($aktivitas['keterangan'] ?? '-'); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($aktivitas['tanggal']); ?>
                                </td>
                            </tr>

                        <?php endwhile; ?>

                    <?php else : ?>

                        <tr>
                            <td colspan="7">Belum ada aktivitas.</td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <!-- PAGINATION AKTIVITAS -->

        <?php if ($total_halaman_aktivitas > 1) : ?>

            <div class="pagination-aktivitas">

                <?php if ($halaman_aktivitas > 1) : ?>

                    <a href="?aktivitas_page=<?php echo $halaman_aktivitas - 1; ?>">
                        &laquo; Sebelumnya
                    </a>

                <?php endif; ?>

                <?php
                $rentang = 2;

                $awal = max(1, $halaman_aktivitas - $rentang);

                $akhir = min(
                    $total_halaman_aktivitas,
                    $halaman_aktivitas + $rentang
                );
                ?>

                <?php if ($awal > 1) : ?>

                    <a href="?aktivitas_page=1">1</a>

                    <?php if ($awal > 2) : ?>
                        <span class="dots">...</span>
                    <?php endif; ?>

                <?php endif; ?>

                <?php for ($i = $awal; $i <= $akhir; $i++) : ?>

                    <?php if ($i == $halaman_aktivitas) : ?>

                        <span class="active">
                            <?php echo $i; ?>
                        </span>

                    <?php else : ?>

                        <a href="?aktivitas_page=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>

                    <?php endif; ?>

                <?php endfor; ?>

                <?php if ($akhir < $total_halaman_aktivitas) : ?>

                    <?php if ($akhir < $total_halaman_aktivitas - 1) : ?>
                        <span class="dots">...</span>
                    <?php endif; ?>

                    <a href="?aktivitas_page=<?php echo $total_halaman_aktivitas; ?>">
                        <?php echo $total_halaman_aktivitas; ?>
                    </a>

                <?php endif; ?>

                <?php if ($halaman_aktivitas < $total_halaman_aktivitas) : ?>

                    <a href="?aktivitas_page=<?php echo $halaman_aktivitas + 1; ?>">
                        Berikutnya &raquo;
                    </a>

                <?php endif; ?>

            </div>

        <?php endif; ?>

        <div class="activity-info">

            Menampilkan
            <?php echo $total_aktivitas > 0 ? $offset_aktivitas + 1 : 0; ?>
            -
            <?php echo min($offset_aktivitas + $batas_aktivitas, $total_aktivitas); ?>
            dari
            <?php echo $total_aktivitas; ?>
            aktivitas

        </div>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
