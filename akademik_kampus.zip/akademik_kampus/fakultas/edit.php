<?php
session_start();
require_once __DIR__ . '/../koneksi.php';
require_once __DIR__ . '/../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    die("ID fakultas tidak valid.");
}

$id = (int) $id;

$stmt = mysqli_prepare($conn, "
    SELECT * FROM fakultas
    WHERE id_fakultas = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$data) {
    die("Data fakultas tidak ditemukan.");
}

if (isset($_POST['update'])) {
    $kode_fakultas = trim($_POST['kode_fakultas']);
    $nama_fakultas = trim($_POST['nama_fakultas']);
    $dekan = trim($_POST['dekan']);

    $stmt = mysqli_prepare($conn, "
        UPDATE fakultas
        SET kode_fakultas = ?, nama_fakultas = ?, dekan = ?
        WHERE id_fakultas = ?
    ");

    if ($stmt) {
        mysqli_stmt_bind_param(
            $stmt,
            "sssi",
            $kode_fakultas,
            $nama_fakultas,
            $dekan,
            $id
        );

        if (mysqli_stmt_execute($stmt)) {
            catatAktivitas(
                $conn,
                'Edit',
                'fakultas',
                $id,
                'Mengubah data fakultas: ' . $nama_fakultas
            );

            mysqli_stmt_close($stmt);

            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal mengubah fakultas. Periksa kembali data yang dimasukkan. Pastikan kode fakultas belum digunakan oleh fakultas lain.";
        }

        mysqli_stmt_close($stmt);
    } else {
        $error = "Gagal menyiapkan perintah perubahan data.";
    }

    // Pertahankan isian pengguna jika proses update gagal.
    $data['kode_fakultas'] = $kode_fakultas;
    $data['nama_fakultas'] = $nama_fakultas;
    $data['dekan'] = $dekan;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Fakultas</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assets/css/edit.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="sidebar-header">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <nav class="sidebar-menu">

        <a href="../../dashboard/index.php">Dashboard</a>
        <a href="../../akun/index.php">Data Akun</a>
        <a href="index.php" class="active">Fakultas</a>
        <a href="../prodi/index.php">Program Studi</a>

        <a href="../mahasiswa/index.php">Mahasiswa</a>
        <a href="../dosen/index.php">Dosen</a>
        <a href="../kelas/index.php">Kelas</a>
        <a href="../perkuliahan/mata_kuliah/index.php">Mata Kuliah</a>
        <a href="../perkuliahan/krs/index.php">KRS</a>

    </nav>

    <div class="sidebar-footer">
        <a href="../../auth/logout.php">Logout</a>
    </div>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Edit Fakultas</h2>
            <p>Silakan ubah informasi fakultas yang ingin diperbarui.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Kode Fakultas</label>
                <input
                    type="text"
                    name="kode_fakultas"
                    value="<?php echo htmlspecialchars($data['kode_fakultas']); ?>"
                    placeholder="Masukkan kode fakultas"
                    maxlength="20"
                    required
                >
            </div>

            <div class="form-group">
                <label>Nama Fakultas</label>
                <input
                    type="text"
                    name="nama_fakultas"
                    value="<?php echo htmlspecialchars($data['nama_fakultas']); ?>"
                    placeholder="Masukkan nama fakultas"
                    maxlength="100"
                    required
                >
            </div>

            <div class="form-group">
                <label>Dekan</label>
                <input
                    type="text"
                    name="dekan"
                    value="<?php echo htmlspecialchars($data['dekan'] ?? ''); ?>"
                    placeholder="Masukkan nama dekan"
                    maxlength="100"
                >
            </div>

            <div class="form-actions">
                <button type="submit" name="update" class="btn btn-save">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>