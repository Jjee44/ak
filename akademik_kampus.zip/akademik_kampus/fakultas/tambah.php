<?php
session_start();
require_once __DIR__ . '/../koneksi.php';
require_once __DIR__ . '/../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $kode_fakultas = trim($_POST['kode_fakultas']);
    $nama_fakultas = trim($_POST['nama_fakultas']);
    $dekan = trim($_POST['dekan']);

    $stmt = mysqli_prepare($conn, "
        INSERT INTO fakultas
        (kode_fakultas, nama_fakultas, dekan)
        VALUES (?, ?, ?)
    ");

    if ($stmt) {
        mysqli_stmt_bind_param(
            $stmt,
            "sss",
            $kode_fakultas,
            $nama_fakultas,
            $dekan
        );

        if (mysqli_stmt_execute($stmt)) {
            $id_baru = mysqli_insert_id($conn);

            catatAktivitas(
                $conn,
                'Tambah',
                'fakultas',
                $id_baru,
                'Menambahkan data fakultas: ' . $nama_fakultas
            );

            mysqli_stmt_close($stmt);

            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal menambahkan fakultas. Periksa kembali data yang dimasukkan. Pastikan kode fakultas belum digunakan.";
        }

        mysqli_stmt_close($stmt);
    } else {
        $error = "Gagal menyiapkan perintah penyimpanan data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Fakultas</title>
    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assets/css/tambah.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <div class="menu-title">Menu Utama</div>

    <a href="../../dashboard/index.php">
        <span>⌂</span> Dashboard
    </a>

    <div class="menu-title">Manajemen Data</div>

    <a href="../../akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="index.php" class="active">
        <span>▤</span> Fakultas
    </a>

    <a href="../prodi/index.php">
        <span>▤</span> Program Studi
    </a>

    <a href="../mahasiswa/index.php">
        <span>♧</span> Mahasiswa
    </a>

    <a href="../dosen/index.php">
        <span>♙</span> Dosen
    </a>

    <a href="../kelas/index.php">
        <span>▦</span> Kelas
    </a>

    <a href="../perkuliahan/mata_kuliah/index.php">
        <span>▣</span> Mata Kuliah
    </a>

    <a href="../perkuliahan/krs/index.php">
        <span>▤</span> KRS
    </a>

    <a href="../../auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Tambah Fakultas</h2>
            <p>Silakan isi informasi fakultas yang akan ditambahkan.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Kode Fakultas</label>
                <input
                    type="text"
                    name="kode_fakultas"
                    value="<?php echo htmlspecialchars($_POST['kode_fakultas'] ?? ''); ?>"
                    placeholder="Masukkan kode fakultas"
                    maxlength="20"
                    required
                >
            </div>

            <div class="form-group">
                <label>Nama Fakultas</label>
                <input
                    type="text"
                    name="nama_fakultas"
                    value="<?php echo htmlspecialchars($_POST['nama_fakultas'] ?? ''); ?>"
                    placeholder="Masukkan nama fakultas"
                    maxlength="100"
                    required
                >
            </div>

            <div class="form-group">
                <label>Dekan</label>
                <input
                    type="text"
                    name="dekan"
                    value="<?php echo htmlspecialchars($_POST['dekan'] ?? ''); ?>"
                    placeholder="Masukkan nama dekan"
                    maxlength="100"
                >
            </div>

            <div class="form-actions">
                <button type="submit" name="simpan" class="btn btn-save">
                    Simpan Data
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>