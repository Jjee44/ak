
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    echo "<script>
        alert('ID data tidak valid.');
        window.location='index.php';
    </script>";
    exit;
}

$id = (int) $id;

// Mengambil nama mahasiswa sebelum data dihapus
$stmt = mysqli_prepare(
    $conn,
    "SELECT nama_mahasiswa FROM mahasiswa WHERE id_mahasiswa = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>
        alert('Data mahasiswa tidak ditemukan.');
        window.location='index.php';
    </script>";
    exit;
}

$nama_mahasiswa = $data['nama_mahasiswa'];

// Menghapus data mahasiswa
$stmt = mysqli_prepare(
    $conn,
    "DELETE FROM mahasiswa WHERE id_mahasiswa = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {

    catatAktivitas(
        $conn,
        'Hapus',
        'mahasiswa',
        $id,
        'Menghapus data mahasiswa: ' . $nama_mahasiswa
    );

    header("Location: index.php");
    exit;
}

echo "<script>
    alert('Data tidak dapat dihapus karena masih digunakan oleh data lain.');
    window.location='index.php';
</script>";
exit;
?>
