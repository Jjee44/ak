
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $nim = trim($_POST['nim']);
    $nama = trim($_POST['nama_mahasiswa']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tanggal_lahir = !empty($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : null;
    $alamat = trim($_POST['alamat'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $id_prodi = (int) $_POST['id_prodi'];

    $stmt = mysqli_prepare($conn, "
        INSERT INTO mahasiswa
        (nim, nama_mahasiswa, jenis_kelamin, tanggal_lahir, alamat, no_hp, email, id_prodi)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "sssssssi",
        $nim,
        $nama,
        $jenis_kelamin,
        $tanggal_lahir,
        $alamat,
        $no_hp,
        $email,
        $id_prodi
    );

    if (mysqli_stmt_execute($stmt)) {
        $id_mahasiswa_baru = mysqli_insert_id($conn);

        catatAktivitas(
            $conn,
            'Tambah',
            'mahasiswa',
            $id_mahasiswa_baru,
            'Menambahkan data mahasiswa: ' . $nama
        );

        header("Location: index.php");
        exit;
    } else {
        $error = "Gagal menyimpan data. Periksa kembali data yang dimasukkan.";
    }
}

$prodi = mysqli_query($conn, "SELECT * FROM prodi ORDER BY nama_prodi ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Mahasiswa</title>

    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/tambah.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <div class="menu-title">Menu Utama</div>

    <a href="../../dashboard/index.php">
        <span>⌂</span> Dashboard
    </a>

    <div class="menu-title">Manajemen Data</div>

    <a href="../../akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="../fakultas/index.php">
        <span>▤</span> Fakultas
    </a>

    <a href="../prodi/index.php">
        <span>▤</span> Program Studi
    </a>

    <a href="index.php" class="active">
        <span>♧</span> Mahasiswa
    </a>

    <a href="../dosen/index.php">
        <span>♙</span> Dosen
    </a>

    <a href="../perkuliahan/mata_kuliah/index.php">
        <span>▣</span> Mata Kuliah
    </a>

    <a href="../kelas/index.php">
        <span>▦</span> Kelas
    </a>

    <a href="../perkuliahan/krs/index.php">
        <span>▤</span> KRS
    </a>

    <a href="../../auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Tambah Mahasiswa</h2>
            <p>Silakan isi informasi mahasiswa yang akan ditambahkan.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>NIM</label>
                <input type="text" name="nim" placeholder="Masukkan NIM" required>
            </div>

            <div class="form-group">
                <label>Nama Mahasiswa</label>
                <input type="text" name="nama_mahasiswa" placeholder="Masukkan nama mahasiswa" required>
            </div>

            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" required>
                    <option value="">Pilih Jenis Kelamin</option>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label>Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir">
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat" placeholder="Masukkan alamat"></textarea>
            </div>

            <div class="form-group">
                <label>No. HP</label>
                <input type="text" name="no_hp" placeholder="Masukkan nomor HP">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Masukkan email">
            </div>

            <div class="form-group">
                <label>Program Studi</label>
                <select name="id_prodi" required>
                    <option value="">Pilih Program Studi</option>

                    <?php while ($data = mysqli_fetch_assoc($prodi)) : ?>
                        <option value="<?php echo $data['id_prodi']; ?>">
                            <?php echo htmlspecialchars($data['nama_prodi']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="simpan" class="btn btn-save">
                    Simpan Data
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
