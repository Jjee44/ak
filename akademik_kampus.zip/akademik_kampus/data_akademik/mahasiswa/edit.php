
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    die("ID mahasiswa tidak valid.");
}

$id = (int) $id;

$stmt = mysqli_prepare($conn, "SELECT * FROM mahasiswa WHERE id_mahasiswa = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Data mahasiswa tidak ditemukan.");
}

if (isset($_POST['update'])) {
    $nim = trim($_POST['nim']);
    $nama = trim($_POST['nama_mahasiswa']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tanggal_lahir = !empty($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : null;
    $alamat = trim($_POST['alamat'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $id_prodi = (int) $_POST['id_prodi'];

    $stmt = mysqli_prepare($conn, "
        UPDATE mahasiswa SET
        nim = ?,
        nama_mahasiswa = ?,
        jenis_kelamin = ?,
        tanggal_lahir = ?,
        alamat = ?,
        no_hp = ?,
        email = ?,
        id_prodi = ?
        WHERE id_mahasiswa = ?
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "sssssssii",
        $nim,
        $nama,
        $jenis_kelamin,
        $tanggal_lahir,
        $alamat,
        $no_hp,
        $email,
        $id_prodi,
        $id
    );

    if (mysqli_stmt_execute($stmt)) {

        catatAktivitas(
            $conn,
            'Edit',
            'mahasiswa',
            $id,
            'Mengubah data mahasiswa: ' . $nama
        );

        header("Location: index.php");
        exit;

    } else {
        $error = "Gagal menyimpan data. Periksa kembali data yang dimasukkan.";
    }
}

$prodi = mysqli_query($conn, "SELECT * FROM prodi ORDER BY nama_prodi ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mahasiswa</title>

    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/edit.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="sidebar-header">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <nav class="sidebar-menu">

        <a href="../../dashboard/index.php">Dashboard</a>
        <a href="../../akun/index.php">Data Akun</a>
        <a href="../fakultas/index.php">Fakultas</a>
        <a href="../prodi/index.php">Program Studi</a>

        <a href="index.php" class="active">Mahasiswa</a>
        <a href="../dosen/index.php">Dosen</a>
        <a href="../perkuliahan/mata_kuliah/index.php">Mata Kuliah</a>
        <a href="../kelas/index.php">Kelas</a>
        <a href="../perkuliahan/krs/index.php">KRS</a>

    </nav>

    <div class="sidebar-footer">
        <a href="../../auth/logout.php">Logout</a>
    </div>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Edit Mahasiswa</h2>
            <p>Silakan ubah informasi mahasiswa yang ingin diperbarui.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>NIM</label>
                <input
                    type="text"
                    name="nim"
                    value="<?php echo htmlspecialchars($data['nim']); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Nama Mahasiswa</label>
                <input
                    type="text"
                    name="nama_mahasiswa"
                    value="<?php echo htmlspecialchars($data['nama_mahasiswa']); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" required>
                    <option value="Laki-laki" <?php if ($data['jenis_kelamin'] == 'Laki-laki') echo 'selected'; ?>>
                        Laki-laki
                    </option>

                    <option value="Perempuan" <?php if ($data['jenis_kelamin'] == 'Perempuan') echo 'selected'; ?>>
                        Perempuan
                    </option>
                </select>
            </div>

            <div class="form-group">
                <label>Tanggal Lahir</label>
                <input
                    type="date"
                    name="tanggal_lahir"
                    value="<?php echo htmlspecialchars($data['tanggal_lahir'] ?? ''); ?>"
                >
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat"><?php echo htmlspecialchars($data['alamat'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label>No. HP</label>
                <input
                    type="text"
                    name="no_hp"
                    value="<?php echo htmlspecialchars($data['no_hp'] ?? ''); ?>"
                >
            </div>

            <div class="form-group">
                <label>Email</label>
                <input
                    type="email"
                    name="email"
                    value="<?php echo htmlspecialchars($data['email'] ?? ''); ?>"
                >
            </div>

            <div class="form-group">
                <label>Program Studi</label>
                <select name="id_prodi" required>

                    <?php while ($p = mysqli_fetch_assoc($prodi)) : ?>
                        <option
                            value="<?php echo $p['id_prodi']; ?>"
                            <?php if ($data['id_prodi'] == $p['id_prodi']) echo 'selected'; ?>
                        >
                            <?php echo htmlspecialchars($p['nama_prodi']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="update" class="btn btn-save">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
