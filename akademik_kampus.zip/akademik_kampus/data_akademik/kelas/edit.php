
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    die("ID kelas tidak valid.");
}

$id = (int) $id;

$stmt = mysqli_prepare($conn, "SELECT * FROM kelas WHERE id_kelas = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Data kelas tidak ditemukan.");
}

if (isset($_POST['update'])) {
    $nama_kelas = trim($_POST['nama_kelas']);
    $tahun_ajaran = trim($_POST['tahun_ajaran']);
    $semester_ajaran = $_POST['semester_ajaran'];
    $id_mk = (int) $_POST['id_mk'];
    $id_dosen = (int) $_POST['id_dosen'];

    $stmt = mysqli_prepare($conn, "
        UPDATE kelas SET
        nama_kelas = ?,
        tahun_ajaran = ?,
        semester_ajaran = ?,
        id_mk = ?,
        id_dosen = ?
        WHERE id_kelas = ?
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "sssiii",
        $nama_kelas,
        $tahun_ajaran,
        $semester_ajaran,
        $id_mk,
        $id_dosen,
        $id
    );

    if (mysqli_stmt_execute($stmt)) {

        catatAktivitas(
            $conn,
            'Edit',
            'kelas',
            $id,
            'Mengubah data kelas: ' . $nama_kelas
        );

        header("Location: index.php");
        exit;

    } else {
        $error = "Gagal menyimpan data. Periksa kembali data yang dimasukkan.";
    }
}

$mk = mysqli_query($conn, "SELECT * FROM mata_kuliah ORDER BY nama_mk ASC");
$dosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY nama_dosen ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kelas</title>

    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/edit.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="sidebar-header">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <nav class="sidebar-menu">

        <a href="../../dashboard/index.php">Dashboard</a>
        <a href="../../akun/index.php">Data Akun</a>
        <a href="../fakultas/index.php">Fakultas</a>
        <a href="../prodi/index.php">Program Studi</a>

        <a href="../mahasiswa/index.php">Mahasiswa</a>
        <a href="../dosen/index.php">Dosen</a>
        <a href="../perkuliahan/mata_kuliah/index.php">Mata Kuliah</a>
        <a href="index.php" class="active">Kelas</a>
        <a href="../perkuliahan/krs/index.php">KRS</a>

    </nav>

    <div class="sidebar-footer">
        <a href="../../auth/logout.php">Logout</a>
    </div>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Edit Kelas</h2>
            <p>Silakan ubah informasi kelas yang ingin diperbarui.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Nama Kelas</label>
                <input
                    type="text"
                    name="nama_kelas"
                    value="<?php echo htmlspecialchars($data['nama_kelas']); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Tahun Ajaran</label>
                <input
                    type="text"
                    name="tahun_ajaran"
                    value="<?php echo htmlspecialchars($data['tahun_ajaran']); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Semester Ajaran</label>
                <select name="semester_ajaran" required>
                    <option value="Ganjil"
                        <?php if ($data['semester_ajaran'] == 'Ganjil') echo 'selected'; ?>>
                        Ganjil
                    </option>

                    <option value="Genap"
                        <?php if ($data['semester_ajaran'] == 'Genap') echo 'selected'; ?>>
                        Genap
                    </option>
                </select>
            </div>

            <div class="form-group">
                <label>Mata Kuliah</label>
                <select name="id_mk" required>

                    <?php while ($m = mysqli_fetch_assoc($mk)) : ?>
                        <option
                            value="<?php echo $m['id_mk']; ?>"
                            <?php if ($data['id_mk'] == $m['id_mk']) echo 'selected'; ?>
                        >
                            <?php echo htmlspecialchars($m['nama_mk']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-group">
                <label>Dosen</label>
                <select name="id_dosen" required>

                    <?php while ($d = mysqli_fetch_assoc($dosen)) : ?>
                        <option
                            value="<?php echo $d['id_dosen']; ?>"
                            <?php if ($data['id_dosen'] == $d['id_dosen']) echo 'selected'; ?>
                        >
                            <?php echo htmlspecialchars($d['nama_dosen']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="update" class="btn btn-save">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
