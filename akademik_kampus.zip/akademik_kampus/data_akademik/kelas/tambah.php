
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $nama_kelas = trim($_POST['nama_kelas']);
    $tahun_ajaran = trim($_POST['tahun_ajaran']);
    $semester_ajaran = $_POST['semester_ajaran'];
    $id_mk = (int) $_POST['id_mk'];
    $id_dosen = (int) $_POST['id_dosen'];

    $stmt = mysqli_prepare($conn, "
        INSERT INTO kelas
        (nama_kelas, tahun_ajaran, semester_ajaran, id_mk, id_dosen)
        VALUES (?, ?, ?, ?, ?)
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "sssii",
        $nama_kelas,
        $tahun_ajaran,
        $semester_ajaran,
        $id_mk,
        $id_dosen
    );

    if (mysqli_stmt_execute($stmt)) {
        $id_kelas_baru = mysqli_insert_id($conn);

        catatAktivitas(
            $conn,
            'Tambah',
            'kelas',
            $id_kelas_baru,
            'Menambahkan data kelas: ' . $nama_kelas
        );

        header("Location: index.php");
        exit;
    } else {
        $error = "Gagal menyimpan data. Periksa kembali data yang dimasukkan.";
    }
}

$mk = mysqli_query($conn, "SELECT * FROM mata_kuliah ORDER BY nama_mk ASC");
$dosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY nama_dosen ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kelas</title>

    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/tambah.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <div class="menu-title">Menu Utama</div>

    <a href="../../dashboard/index.php">
        <span>⌂</span> Dashboard
    </a>

    <div class="menu-title">Manajemen Data</div>

    <a href="../../akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="../fakultas/index.php">
        <span>▤</span> Fakultas
    </a>

    <a href="../prodi/index.php">
        <span>▤</span> Program Studi
    </a>

    <a href="../mahasiswa/index.php">
        <span>♧</span> Mahasiswa
    </a>

    <a href="../dosen/index.php">
        <span>♙</span> Dosen
    </a>

    <a href="../perkuliahan/mata_kuliah/index.php">
        <span>▣</span> Mata Kuliah
    </a>

    <a href="index.php" class="active">
        <span>▦</span> Kelas
    </a>

    <a href="../perkuliahan/krs/index.php">
        <span>▤</span> KRS
    </a>

    <a href="../../auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Tambah Kelas</h2>
            <p>Silakan isi informasi kelas yang akan ditambahkan.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Nama Kelas</label>
                <input
                    type="text"
                    name="nama_kelas"
                    placeholder="Masukkan nama kelas"
                    required
                >
            </div>

            <div class="form-group">
                <label>Tahun Ajaran</label>
                <input
                    type="text"
                    name="tahun_ajaran"
                    placeholder="Contoh: 2026/2027"
                    required
                >
            </div>

            <div class="form-group">
                <label>Semester Ajaran</label>
                <select name="semester_ajaran" required>
                    <option value="">Pilih Semester</option>
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                </select>
            </div>

            <div class="form-group">
                <label>Mata Kuliah</label>
                <select name="id_mk" required>
                    <option value="">Pilih Mata Kuliah</option>

                    <?php while ($m = mysqli_fetch_assoc($mk)) : ?>
                        <option value="<?php echo $m['id_mk']; ?>">
                            <?php echo htmlspecialchars($m['nama_mk']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-group">
                <label>Dosen</label>
                <select name="id_dosen" required>
                    <option value="">Pilih Dosen</option>

                    <?php while ($d = mysqli_fetch_assoc($dosen)) : ?>
                        <option value="<?php echo $d['id_dosen']; ?>">
                            <?php echo htmlspecialchars($d['nama_dosen']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="simpan" class="btn btn-save">
                    Simpan Data
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
