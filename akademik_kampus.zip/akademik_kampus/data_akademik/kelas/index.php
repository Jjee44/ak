
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$query = mysqli_query($conn, "
    SELECT
        kelas.*,
        mata_kuliah.nama_mk,
        dosen.nama_dosen
    FROM kelas
    JOIN mata_kuliah
        ON kelas.id_mk = mata_kuliah.id_mk
    JOIN dosen
        ON kelas.id_dosen = dosen.id_dosen
    ORDER BY kelas.id_kelas ASC
");

if (!$query) {
    die("Gagal mengambil data kelas: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kelas - Akademik Kampus</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK KAMPUS</h2>
        <p>INFORMATION SYSTEM</p>
    </div>

    <div class="menu-title">MENU UTAMA</div>

    <a href="../../dashboard/index.php">
        <span>▦</span> Dashboard
    </a>

    <a href="../../akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="../fakultas/index.php">
        <span>▤</span> Fakultas
    </a>

    <a href="../prodi/index.php">
        <span>▤</span> Program Studi
    </a>

    <div class="menu-title">DATA AKADEMIK</div>

    <a href="../mahasiswa/index.php">
        <span>♙</span> Mahasiswa
    </a>

    <a href="../dosen/index.php">
        <span>♧</span> Dosen
    </a>

    <a href="index.php" class="active">
        <span>▣</span> Kelas
    </a>

    <div class="menu-title">PERKULIAHAN</div>

    <a href="../perkuliahan/mata_kuliah/index.php">
        <span>▤</span> Mata Kuliah
    </a>

    <a href="../perkuliahan/krs/index.php">
        <span>▣</span> KRS
    </a>

    <div class="menu-title">LAINNYA</div>

    <a href="../../auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <header class="topbar">
        <h3>Data Kelas</h3>

        <div class="akun-info">
            Akun:
            <strong>
                <?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>
            </strong>
        </div>
    </header>

    <section class="content">

        <div class="page-heading">
            <div>
                <h1>Data Kelas</h1>
                <p>Daftar kelas perkuliahan kampus.</p>
            </div>

            <a href="tambah.php" class="btn-add">
                + Tambah Kelas
            </a>
        </div>

        <div class="data-card">

            <div class="card-header">
                <h3>Daftar Kelas</h3>

                <span class="total-data">
                    Total Data: <?php echo mysqli_num_rows($query); ?>
                </span>
            </div>

            <div class="table-wrapper">

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Kelas</th>
                            <th>Tahun Ajaran</th>
                            <th>Semester Ajaran</th>
                            <th>Mata Kuliah</th>
                            <th>Dosen</th>
                            <th>Perubahan</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (mysqli_num_rows($query) > 0) : ?>

                            <?php while ($data = mysqli_fetch_assoc($query)) : ?>

                                <tr>
                                    <td>
                                        <span class="id-badge">
                                            <?php echo $data['id_kelas']; ?>
                                        </span>
                                    </td>

                                    <td>
                                        <strong>
                                            <?php echo htmlspecialchars($data['nama_kelas']); ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['tahun_ajaran']); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['semester_ajaran']); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['nama_mk']); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['nama_dosen']); ?>
                                    </td>

                                    <td>
                                        <div class="action">

                                            <a
                                                href="edit.php?id=<?php echo $data['id_kelas']; ?>"
                                                class="btn-edit"
                                            >
                                                Edit
                                            </a>

                                            <a
                                                href="hapus.php?id=<?php echo $data['id_kelas']; ?>"
                                                class="btn-delete"
                                                onclick="return confirm('Yakin ingin menghapus kelas ini?')"
                                            >
                                                Hapus
                                            </a>

                                        </div>
                                    </td>
                                </tr>

                            <?php endwhile; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="7" class="empty">
                                    Belum ada data kelas.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>
                </table>

            </div>

        </div>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
