
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id <= 0) {
    echo "<script>
        alert('ID data tidak valid.');
        window.location='index.php';
    </script>";
    exit;
}

$id = (int) $id;

// Mengambil nama kelas sebelum data dihapus
$stmt = mysqli_prepare(
    $conn,
    "SELECT nama_kelas FROM kelas WHERE id_kelas = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>
        alert('Data kelas tidak ditemukan.');
        window.location='index.php';
    </script>";
    exit;
}

$nama_kelas = $data['nama_kelas'];

// Menghapus data kelas
$stmt = mysqli_prepare(
    $conn,
    "DELETE FROM kelas WHERE id_kelas = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {

    // Mencatat aktivitas setelah penghapusan berhasil
    catatAktivitas(
        $conn,
        'Hapus',
        'kelas',
        $id,
        'Menghapus data kelas: ' . $nama_kelas
    );

    header("Location: index.php");
    exit;
}

echo "<script>
    alert('Data tidak dapat dihapus karena masih digunakan oleh data lain.');
    window.location='index.php';
</script>";
exit;
?>
