
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || $id === '') {
    echo "<script>
        alert('ID data tidak valid.');
        window.location='index.php';
    </script>";
    exit;
}

// Mengambil nama dosen sebelum dihapus
$stmt = mysqli_prepare($conn, "
    SELECT nama_dosen FROM dosen WHERE id_dosen = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>
        alert('Data dosen tidak ditemukan.');
        window.location='index.php';
    </script>";
    exit;
}

$nama_dosen = $data['nama_dosen'];

// Menghapus data dosen
$stmt = mysqli_prepare($conn, "
    DELETE FROM dosen WHERE id_dosen = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {

    catatAktivitas(
        $conn,
        'Hapus',
        'dosen',
        $id,
        'Menghapus data dosen: ' . $nama_dosen
    );

    header("Location: index.php");
    exit;
}

echo "<script>
    alert('Data tidak dapat dihapus karena masih digunakan oleh data lain.');
    window.location='index.php';
</script>";
exit;
?>
