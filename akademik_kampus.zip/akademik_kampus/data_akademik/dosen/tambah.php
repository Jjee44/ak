
<?php
session_start();
require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../../auth/login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $nidn = $_POST['nidn'];
    $nama = $_POST['nama_dosen'];
    $jk = $_POST['jenis_kelamin'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];
    $email = $_POST['email'];
    $id_prodi = $_POST['id_prodi'];

    $stmt = mysqli_prepare($conn, "
        INSERT INTO dosen
        (nidn, nama_dosen, jenis_kelamin, alamat, no_hp, email, id_prodi)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "ssssssi",
        $nidn,
        $nama,
        $jk,
        $alamat,
        $no_hp,
        $email,
        $id_prodi
    );

    if (mysqli_stmt_execute($stmt)) {

        $id_dosen_baru = mysqli_insert_id($conn);

        catatAktivitas(
            $conn,
            'Tambah',
            'dosen',
            $id_dosen_baru,
            'Menambahkan data dosen: ' . $nama
        );

        header("Location: index.php");
        exit;

    } else {
        $error = "Gagal menyimpan data. Periksa kembali data yang dimasukkan.";
    }
}

$prodi = mysqli_query($conn, "
    SELECT * FROM prodi ORDER BY nama_prodi ASC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Dosen</title>

    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/tambah.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK KAMPUS</h2>
        <p>INFORMATION SYSTEM</p>
    </div>

    <div class="menu-title">MENU UTAMA</div>
    <a href="../../dashboard/index.php"><span>▦</span> Dashboard</a>
    <a href="../../akun/index.php"><span>♙</span> Data Akun</a>
    <a href="../fakultas/index.php"><span>▤</span> Fakultas</a>
    <a href="../prodi/index.php"><span>▤</span> Program Studi</a>

    <div class="menu-title">DATA AKADEMIK</div>
    <a href="../mahasiswa/index.php"><span>♙</span> Mahasiswa</a>
    <a href="index.php" class="active"><span>♧</span> Dosen</a>
    <a href="../kelas/index.php"><span>▣</span> Kelas</a>

    <div class="menu-title">PERKULIAHAN</div>
    <a href="../perkuliahan/mata_kuliah/index.php"><span>▤</span> Mata Kuliah</a>
    <a href="../perkuliahan/krs/index.php"><span>▣</span> KRS</a>

    <div class="menu-title">LAINNYA</div>
    <a href="../../auth/logout.php" class="logout"><span>↪</span> Logout</a>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Tambah Dosen</h2>
            <p>Silakan isi informasi dosen yang akan ditambahkan.</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>NIDN</label>
                <input type="text" name="nidn"
                       placeholder="Masukkan NIDN" required>
            </div>

            <div class="form-group">
                <label>Nama Dosen</label>
                <input type="text" name="nama_dosen"
                       placeholder="Masukkan nama dosen" required>
            </div>

            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" required>
                    <option value="">Pilih Jenis Kelamin</option>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat" placeholder="Masukkan alamat"></textarea>
            </div>

            <div class="form-group">
                <label>No. HP</label>
                <input type="text" name="no_hp"
                       placeholder="Masukkan nomor HP">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email"
                       placeholder="Masukkan email">
            </div>

            <div class="form-group">
                <label>Program Studi</label>
                <select name="id_prodi" required>
                    <option value="">Pilih Program Studi</option>

                    <?php while ($p = mysqli_fetch_assoc($prodi)) : ?>
                        <option value="<?php echo $p['id_prodi']; ?>">
                            <?php echo htmlspecialchars($p['nama_prodi']); ?>
                        </option>
                    <?php endwhile; ?>

                </select>
            </div>

            <div class="form-actions">
                <button type="submit" name="simpan" class="btn btn-save">
                    Simpan Data
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>
