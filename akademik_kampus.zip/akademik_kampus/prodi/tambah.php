<?php
session_start();

require_once __DIR__ . '/../koneksi.php';
require_once __DIR__ . '/../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../auth/login.php");
    exit;
}

$error = '';

if (isset($_POST['simpan'])) {
    $nama_prodi = trim($_POST['nama_prodi'] ?? '');
    $jenjang = $_POST['jenjang'] ?? '';
    $akreditasi = trim($_POST['akreditasi'] ?? '');
    $ketua_prodi = trim($_POST['ketua_prodi'] ?? '');

    $jenjang_valid = ['D3', 'D4', 'S1', 'S2'];

    if (
        $nama_prodi === '' ||
        !in_array($jenjang, $jenjang_valid, true)
    ) {
        $error = "Nama program studi dan jenjang wajib diisi dengan benar.";
    } else {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO prodi
            (nama_prodi, jenjang, akreditasi, ketua_prodi)
            VALUES (?, ?, ?, ?)
        ");

        if ($stmt) {
            mysqli_stmt_bind_param(
                $stmt,
                "ssss",
                $nama_prodi,
                $jenjang,
                $akreditasi,
                $ketua_prodi
            );

            if (mysqli_stmt_execute($stmt)) {
                $id_baru = mysqli_insert_id($conn);

                catatAktivitas(
                    $conn,
                    'Tambah',
                    'prodi',
                    $id_baru,
                    "Menambahkan program studi: " . $nama_prodi
                );

                mysqli_stmt_close($stmt);

                header("Location: index.php");
                exit;
            } else {
                $error = "Gagal menambahkan program studi. Periksa kembali data yang dimasukkan.";
            }

            mysqli_stmt_close($stmt);
        } else {
            $error = "Gagal menyiapkan penyimpanan data.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Program Studi</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assets/css/tambah.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <div class="menu-title">MENU UTAMA</div>

    <a href="../dashboard/index.php">
        <span>⌂</span> Dashboard
    </a>

    <a href="../akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="index.php" class="active">
        <span>▤</span> Program Studi
    </a>

    <div class="menu-title">DATA AKADEMIK</div>

    <a href="fakultas/index.php">
        <span>▣</span> Fakultas
    </a>

    <a href="../data_akademik/mahasiswa/index.php">
        <span>♧</span> Mahasiswa
    </a>

    <a href="../data_akademik/dosen/index.php">
        <span>♙</span> Dosen
    </a>

    <a href="../data_akademik/kelas/index.php">
        <span>▦</span> Kelas
    </a>

    <div class="menu-title">PERKULIAHAN</div>

    <a href="../perkuliahan/mata_kuliah/index.php">
        <span>▣</span> Mata Kuliah
    </a>

    <a href="../perkuliahan/krs/index.php">
        <span>▤</span> KRS
    </a>

    <div class="menu-title">LAINNYA</div>

    <a href="../auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Tambah Program Studi</h2>
            <p>Silakan isi informasi program studi yang akan ditambahkan.</p>
        </div>

        <?php if ($error !== '') : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Nama Program Studi</label>
                <input
                    type="text"
                    name="nama_prodi"
                    value="<?php echo htmlspecialchars($_POST['nama_prodi'] ?? ''); ?>"
                    placeholder="Masukkan nama program studi"
                    required
                >
            </div>

            <div class="form-group">
                <label>Jenjang</label>
                <select name="jenjang" required>
                    <option value="">Pilih Jenjang</option>

                    <?php
                    $jenjang_list = ['D3', 'D4', 'S1', 'S2'];

                    foreach ($jenjang_list as $j) :
                    ?>
                        <option
                            value="<?php echo $j; ?>"
                            <?php
                            if (($_POST['jenjang'] ?? '') === $j) {
                                echo 'selected';
                            }
                            ?>
                        >
                            <?php echo $j; ?>
                        </option>
                    <?php endforeach; ?>

                </select>
            </div>

            <div class="form-group">
                <label>Akreditasi</label>
                <input
                    type="text"
                    name="akreditasi"
                    value="<?php echo htmlspecialchars($_POST['akreditasi'] ?? ''); ?>"
                    placeholder="Masukkan akreditasi"
                >
            </div>

            <div class="form-group">
                <label>Ketua Program Studi</label>
                <input
                    type="text"
                    name="ketua_prodi"
                    value="<?php echo htmlspecialchars($_POST['ketua_prodi'] ?? ''); ?>"
                    placeholder="Masukkan nama ketua program studi"
                >
            </div>

            <div class="form-actions">
                <button type="submit" name="simpan" class="btn btn-save">
                    Simpan Data
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>