<?php
session_start();

require_once __DIR__ . '/../koneksi.php';
require_once __DIR__ . '/../aktivitas.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!ctype_digit((string) $id) || (int) $id < 1) {
    die("ID program studi tidak valid.");
}

$id = (int) $id;

$stmt = mysqli_prepare(
    $conn,
    "SELECT * FROM prodi WHERE id_prodi = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$data) {
    die("Data program studi tidak ditemukan.");
}

$error = '';

if (isset($_POST['update'])) {
    $nama_prodi = trim($_POST['nama_prodi'] ?? '');
    $jenjang = $_POST['jenjang'] ?? '';
    $akreditasi = trim($_POST['akreditasi'] ?? '');
    $ketua_prodi = trim($_POST['ketua_prodi'] ?? '');

    $jenjang_valid = ['D3', 'D4', 'S1', 'S2'];

    if (
        $nama_prodi === '' ||
        !in_array($jenjang, $jenjang_valid, true)
    ) {
        $error = "Nama program studi dan jenjang wajib diisi dengan benar.";
    } else {
        $stmt = mysqli_prepare($conn, "
            UPDATE prodi
            SET nama_prodi = ?,
                jenjang = ?,
                akreditasi = ?,
                ketua_prodi = ?
            WHERE id_prodi = ?
        ");

        if ($stmt) {
            mysqli_stmt_bind_param(
                $stmt,
                "ssssi",
                $nama_prodi,
                $jenjang,
                $akreditasi,
                $ketua_prodi,
                $id
            );

            if (mysqli_stmt_execute($stmt)) {
                catatAktivitas(
                    $conn,
                    'Edit',
                    'prodi',
                    $id,
                    "Mengubah data program studi: " . $nama_prodi
                );

                mysqli_stmt_close($stmt);

                header("Location: index.php");
                exit;
            } else {
                $error = "Gagal mengubah program studi. Periksa kembali data yang dimasukkan.";
            }

            mysqli_stmt_close($stmt);
        } else {
            $error = "Gagal menyiapkan perubahan data.";
        }
    }

    // Mempertahankan data formulir apabila terjadi kesalahan.
    $data['nama_prodi'] = $nama_prodi;
    $data['jenjang'] = $jenjang;
    $data['akreditasi'] = $akreditasi;
    $data['ketua_prodi'] = $ketua_prodi;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Program Studi</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
    <link rel="stylesheet" href="/akademik_kampus/assets/css/edit.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="sidebar-header">
        <h2>AKADEMIK</h2>
        <p>Sistem Informasi Kampus</p>
    </div>

    <nav class="sidebar-menu">

        <a href="../dashboard/index.php">Dashboard</a>
        <a href="../akun/index.php">Data Akun</a>
        <a href="index.php" class="active">Program Studi</a>
        <a href="../data_akademik/fakultas/index.php">Fakultas</a>

        <a href="../data_akademik/mahasiswa/index.php">Mahasiswa</a>
        <a href="../data_akademik/dosen/index.php">Dosen</a>
        <a href="../data_akademik/kelas/index.php">Kelas</a>
        <a href="../perkuliahan/mata_kuliah/index.php">Mata Kuliah</a>
        <a href="../perkuliahan/krs/index.php">KRS</a>

    </nav>

    <div class="sidebar-footer">
        <a href="../auth/logout.php">Logout</a>
    </div>

</aside>

<main class="main">

    <section class="form-card">

        <div class="form-heading">
            <h2>Form Edit Program Studi</h2>
            <p>Silakan ubah informasi program studi yang ingin diperbarui.</p>
        </div>

        <?php if ($error !== '') : ?>
            <div class="form-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Nama Program Studi</label>
                <input
                    type="text"
                    name="nama_prodi"
                    value="<?php echo htmlspecialchars($data['nama_prodi']); ?>"
                    placeholder="Masukkan nama program studi"
                    required
                >
            </div>

            <div class="form-group">
                <label>Jenjang</label>
                <select name="jenjang" required>
                    <option value="">Pilih Jenjang</option>

                    <option value="D3" <?php if ($data['jenjang'] == 'D3') echo 'selected'; ?>>D3</option>
                    <option value="D4" <?php if ($data['jenjang'] == 'D4') echo 'selected'; ?>>D4</option>
                    <option value="S1" <?php if ($data['jenjang'] == 'S1') echo 'selected'; ?>>S1</option>
                    <option value="S2" <?php if ($data['jenjang'] == 'S2') echo 'selected'; ?>>S2</option>
                </select>
            </div>

            <div class="form-group">
                <label>Akreditasi</label>
                <input
                    type="text"
                    name="akreditasi"
                    value="<?php echo htmlspecialchars($data['akreditasi'] ?? ''); ?>"
                    placeholder="Masukkan akreditasi"
                >
            </div>

            <div class="form-group">
                <label>Ketua Program Studi</label>
                <input
                    type="text"
                    name="ketua_prodi"
                    value="<?php echo htmlspecialchars($data['ketua_prodi'] ?? ''); ?>"
                    placeholder="Masukkan nama ketua program studi"
                >
            </div>

            <div class="form-actions">
                <button type="submit" name="update" class="btn btn-save">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-cancel">
                    Batal
                </a>
            </div>

        </form>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>