<?php
session_start();

require_once __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['id_akun'])) {
    header("Location: ../auth/login.php");
    exit;
}

$query = mysqli_query(
    $conn,
    "SELECT * FROM prodi ORDER BY id_prodi ASC"
);

if (!$query) {
    die("Gagal mengambil data program studi: " . mysqli_error($conn));
}

$total = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Program Studi - Akademik Kampus</title>

    <link rel="stylesheet" href="/akademik_kampus/assets/css/style.css">
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<aside class="sidebar">

    <div class="brand">
        <h2>AKADEMIK KAMPUS</h2>
        <p>INFORMATION SYSTEM</p>
    </div>

    <div class="menu-title">MENU UTAMA</div>

    <a href="../dashboard/index.php">
        <span>▦</span> Dashboard
    </a>

    <a href="../akun/index.php">
        <span>♙</span> Data Akun
    </a>

    <a href="index.php" class="active">
        <span>▤</span> Program Studi
    </a>

    <div class="menu-title">DATA AKADEMIK</div>

    <a href="fakultas/index.php">
        <span>▣</span> Fakultas
    </a>

    <a href="../data_akademik/mahasiswa/index.php">
        <span>♙</span> Mahasiswa
    </a>

    <a href="../data_akademik/dosen/index.php">
        <span>♧</span> Dosen
    </a>

    <a href="../data_akademik/kelas/index.php">
        <span>▣</span> Kelas
    </a>

    <div class="menu-title">PERKULIAHAN</div>

    <a href="../perkuliahan/mata_kuliah/index.php">
        <span>▤</span> Mata Kuliah
    </a>

    <a href="../perkuliahan/krs/index.php">
        <span>▣</span> KRS
    </a>

    <div class="menu-title">LAINNYA</div>

    <a href="../auth/logout.php" class="logout">
        <span>↪</span> Logout
    </a>

</aside>

<main class="main">

    <header class="topbar">
        <h3>Data Program Studi</h3>

        <div class="akun-info">
            Akun:
            <strong>
                <?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>
            </strong>
        </div>
    </header>

    <section class="content">

        <div class="page-heading">
            <div>
                <h1>Program Studi</h1>
                <p>Kelola informasi program studi kampus.</p>
            </div>

            <a href="tambah.php" class="btn-add">
                + Tambah Program Studi
            </a>
        </div>

        <div class="data-card">

            <div class="card-header">
                <h3>Daftar Program Studi</h3>

                <span class="total-data">
                    Total: <?php echo $total; ?> Data
                </span>
            </div>

            <div class="table-wrapper">

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Program Studi</th>
                            <th>Jenjang</th>
                            <th>Akreditasi</th>
                            <th>Ketua Program Studi</th>
                            <th>Perubahan</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if ($total > 0) : ?>

                            <?php while ($data = mysqli_fetch_assoc($query)) : ?>
                                <tr>

                                    <td>
                                        <span class="id-badge">
                                            <?php echo $data['id_prodi']; ?>
                                        </span>
                                    </td>

                                    <td>
                                        <strong>
                                            <?php echo htmlspecialchars($data['nama_prodi']); ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['jenjang']); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['akreditasi'] ?? '-'); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($data['ketua_prodi'] ?? '-'); ?>
                                    </td>

                                    <td>
                                        <div class="action">

                                            <a
                                                class="btn-edit"
                                                href="edit.php?id=<?php echo $data['id_prodi']; ?>"
                                            >
                                                Edit
                                            </a>

                                            <a
                                                class="btn-delete"
                                                href="hapus.php?id=<?php echo $data['id_prodi']; ?>"
                                                onclick="return confirm('Yakin ingin menghapus program studi ini?')"
                                            >
                                                Hapus
                                            </a>

                                        </div>
                                    </td>

                                </tr>
                            <?php endwhile; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="6" class="empty">
                                    Belum ada data program studi.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>
                </table>

            </div>

        </div>

    </section>

</main>

<script>
function toggleSidebar() {
    document.body.classList.toggle('sidebar-closed');
}
</script>

</body>
</html>